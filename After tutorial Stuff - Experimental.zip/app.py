from flask import Flask, render_template, redirect, request
from flask.globals import request
from forms import SignUpForm

################## NEW ########################
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
################## NEW ########################



app = Flask(__name__)
app.config['SECRET_KEY'] = 'guacbanana'

################## NEW ########################
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///userEntry2.db'
db = SQLAlchemy(app)
################## NEW ########################
#go back to here for for loops, to loop through the program and print it to the page https://www.youtube.com/watch?v=xh3mFxbnc4o&list=PLB5jA40tNf3vX6Ue_ud64DDRVSryHHr1h&index=4

@app.route('/')
def home():
    return "Meow"

@app.route('/about')
def about():
    return (render_template('about.html', author="Jerry", sunny=False))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignUpForm()
    if form.is_submitted():
        result = request.form

        try:
            #sqlExe = "INSERT INTO userInfo({},{},{},{});".format(result.get("first_name"), result.get("last_name"), result.get("email"),result.get("sport"))
            #print(sqlExe)
            sqlExe = 'INSERT INTO "main"."userInfo"("first_name","last_name","email","sport") VALUES ("{}","{}","{}","{}");'.format(result.get("first_name"), result.get("last_name"), result.get("email"),result.get("sport"))
            db.session.execute(sqlExe)
            db.session.commit()

            print("Your info was successfully added")

        except Exception as e:
            print(e)
            print("Your query couldn't be inserted into the databse")


        #print(result)
        return render_template('user.html', result=result)

    return render_template('signup.html', form=form)


if __name__ == '__main__':
    app.run()

